package com.example.bhaskaratp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
