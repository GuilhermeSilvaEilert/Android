abstract class CalculoDoisFatores{

 double? CalculaDoisValores({double? valorA, double? valorB});

}